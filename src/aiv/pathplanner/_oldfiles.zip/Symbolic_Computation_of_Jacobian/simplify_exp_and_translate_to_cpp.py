import re
import sys

def derivrplEq(mo):
	#print '\nderiv g0: ', mo.group(0)
	#print '\nderiv g1: ', mo.group(1)
	#print '\nderiv g2: ', mo.group(2)
	#print mo.group(1) == mo.group(2)
	if mo.group(1) == mo.group(2):
		return '1.0'
	else:
		return '0.0'

def derivrplmEq(mo):
	#print '\nderiv g1: ', mo.group(1)
	#print '\nderiv g2: ', mo.group(2)
	#print mo.group(1) == mo.group(2)
	if mo.group(1) == mo.group(2):
		return '-1.0'
	else:
		return '0.0'

def rplComplicPowL(m, eqCons, offset):
	nclosedp = 1
	idx = m.start()-1 + offset
	#print 'idx', idx
	while nclosedp > 0:
		if eqCons[idx] == '(':
			nclosedp -= 1
		elif eqCons[idx] == ')':
			nclosedp += 1
		idx -= 1
	#print 'idx2', idx

	nEqCons = eqCons[0:idx+1] +\
		'(pow(' + eqCons[idx+2:m.start()+offset] + ', ' + eqCons[m.end()-len(m.group(1))+offset:m.end()+offset] + '))' +\
		eqCons[m.end()+offset:]

	#print nEqCons

	return nEqCons

def rplComplicPowD(m, eqCons, offset):
	nclosedp = 1
	idx = m.end() + offset
	#print 'idx', idx
	while nclosedp > 0:
		if eqCons[idx] == ')':
			nclosedp -= 1
		elif eqCons[idx] == '(':
			nclosedp += 1
		idx += 1
	#print 'idx2', idx

	nEqCons = eqCons[0:m.start()+offset] +\
		'(pow(' + eqCons[m.start()+offset:m.end()-3+offset] + ', ' + eqCons[m.end():idx-1] +\
		'))' +\
		eqCons[idx:]

	#print nEqCons

	return nEqCons

def addParenthesis(m, eqCons, offset):
	nopenedp = 1
	idx = m.end() + 1 + offset
	#print 'idx', idx
	while nopenedp > 0:
		if eqCons[idx] == ')':
			nopenedp -= 1
		elif eqCons[idx] == '(':
			nopenedp += 1
		idx += 1
	#print 'idx', idx
	#print eqCons[idx:-1]

	nEqCons = eqCons[0:m.start()+offset] +\
		'(' +\
		eqCons[m.start()+offset:idx] +\
		')' +\
		eqCons[idx:]

	#print '\n', nEqCons, '\n'
	return nEqCons

print str(sys.argv[1][0:-3])+'cpp'

f = open(str(sys.argv[1]), 'r')
eqCons = f.read()


#eqCons = '(balalab)**2--(balj - (3**t)(3 + (Abs(ala)) + b)**2--im(X1_1) re(X1_12) Derivative(-X1_1, X1_1) Derivative(X1_1, X1_2) Derivative(X1_1, -im(X1_2))'

#eqCons = '3**t + (32*t**2*(6*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)*(-re(X1_4) + re(X1_6))/Tp + 32*t**2*(-re(X1_6) + re(X1_8))/Tp**3 + 192*(Tp/4 - t)**2*(-re(X1_2) + re(X1_4))/Tp**3)*Derivative(re(X1_8), X1_7)/Tp**3 + 32*t**2*(6*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)*(-im(X1_3) + im(X1_5))/Tp + 32*t**2*(-im(X1_5) + im(X1_7))/Tp**3 + 192*(Tp/4 - t)**2*(-im(X1_1) + im(X1_3))/Tp**3)*Derivative(im(X1_7), X1_7)/Tp**3)/sqrt(Abs(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_5 + X1_7)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_1 + X1_3)/Tp**3)**2 + Abs(6*(-X1_4 + X1_6)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_6 + X1_8)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_2 + X1_4)/Tp**3)**2)'

#eqCons = 'sqrt(1) abs(2) abs(sqrt(tfsdf)) abs(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + sqrt(8)*t*(Tp/2 - t)/Tp**2)/Tp + 32*pow(t, 2)*(-X1_5 + X1_7)/pow(Tp, 3) + 192*pow(Tp/4 - t, 2)*(-X1_1 + X1_3)/pow(Tp, 3))**2'
#eqCons = 'sqrt(1) abs(2)'
#print eqCons

#eqCons = '(((t + (3+4))**5 + (coco**tetat + (t+(3/3))**(4/3) + (Tp + (4/3) + t)**(3/2) * (d+abs(X1_2))+1 + t**14.5)**2)**3)'
#eqCons = '((1+1*U*(5+(4))**(coco))**(foo))'
#eqCons = '(t+4)**(4/3) + beta.teta**(t+e+3/3*1.3) + (t+e+3/3*1.3)**beta.teta - cisco**tomato.cpp + (t + (1/2.5))**coco + (X*(1/2.5))**(coco) + coco**(X*(4/3)) + (chica)**(X*(4.5)) + ((t + (1/2.5))**2)'
#eqCons = '(r*(2+33))**2 + (t+(3+(5))**5 + 5)**t'

#eqCons = 'a = ((32*t*(3*X1_3 - 5*X1_5 + 2*X1_7)/Tp**3 + 192*(Tp/4 - t)*(2*X1_1 - 3*X1_3 + X1_5)/Tp**3)*(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_5 + X1_7)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_1 + X1_3)/Tp**3) + (32*t*(3*X1_4 - 5*X1_6 + 2*X1_8)/Tp**3 + 192*(Tp/4 - t)*(2*X1_2 - 3*X1_4 + X1_6)/Tp**3)*(6*(-X1_4 + X1_6)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_6 + X1_8)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_2 + X1_4)/Tp**3))*(192*(Tp/4 - t)**2*(6*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)*(-re(X1_3) + re(X1_5))/Tp + 32*t**2*(-re(X1_5) + re(X1_7))/Tp**3 + 192*(Tp/4 - t)**2*(-re(X1_1) + re(X1_3))/Tp**3)*Derivative(re(X1_1), X1_1)/Tp**3 + 192*(Tp/4 - t)**2*(6*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)*(-im(X1_3) + im(X1_5))/Tp + 32*t**2*(-im(X1_5) + im(X1_7))/Tp**3 + 192*(Tp/4 - t)**2*(-im(X1_1) + im(X1_3))/Tp**3)*Derivative(im(X1_1), X1_1)/Tp**3)/(Abs(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_5 + X1_7)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_1 + X1_3)/Tp**3)**2 + Abs(6*(-X1_4 + X1_6)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_6 + X1_8)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_2 + X1_4)/Tp**3)**2)**(3/2) + (-192*(Tp/4 - t)**2*(32*t*(3*X1_3 - 5*X1_5 + 2*X1_7)/Tp**3 + 192*(Tp/4 - t)*(2*X1_1 - 3*X1_3 + X1_5)/Tp**3)/Tp**3 + 384*(Tp/4 - t)*(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_5 + X1_7)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_1 + X1_3)/Tp**3)/Tp**3)/sqrt(Abs(6*(-X1_3 + X1_5)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_5 + X1_7)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_1 + X1_3)/Tp**3)**2 + Abs(6*(-X1_4 + X1_6)*(16*t*(Tp/4 - t)/Tp**2 + 8*t*(Tp/2 - t)/Tp**2)/Tp + 32*t**2*(-X1_6 + X1_8)/Tp**3 + 192*(Tp/4 - t)**2*(-X1_2 + X1_4)/Tp**3)**2)'
#eqCons = '((pow(6*(-X[2] + X[4])*(16*t*(Tp/4 - t)/(pow(Tp, 2)) + 8*t*(Tp/2 - t)/(pow(Tp, 2)))/Tp + 32*(pow(t, 2))*(-X[4] + X[6])/(pow(Tp, 3)) + 192*(pow(Tp/4 - t, 2))*(-X[0] + X[2])/(pow(Tp, 3)), 2)) + (pow(6*(-X[3] + X[5])*(16*t*(Tp/4 - t)/(pow(Tp, 2)) + 8*t*(Tp/2 - t)/(pow(Tp, 2)))/Tp + 32*(pow(t, 2))*(-X[5] + X[7])/(pow(Tp, 3)) + 192*(pow(Tp/4 - t, 2))*(-X[1] + X[3])/(pow(Tp, 3)), 2)))**2'

eqCons = re.sub(r'Abs', r'abs', eqCons)

# eqCons = re.sub(r're\((X1_[0-9]+)\)', r'\1', eqCons)
# eqCons = re.sub(r'im\(X1_[0-9]+\)', r'0.0', eqCons)

# eqCons = re.sub(r'conjugate\((X1_[0-9]+)\)', r'\1', eqCons)

# eqCons = re.sub(r'Derivative\(([^)-]+),\s([^)-]+)\)', derivrplEq, eqCons)
# eqCons = re.sub(r'Derivative\(-([^)-]+),\s([^)-]+)\)', derivrplmEq, eqCons)
# eqCons = re.sub(r'Derivative\(([^)-]+),\s-([^)-]+)\)', derivrplmEq, eqCons)
# eqCons = re.sub(r'Derivative\(-([^)-]+),\s-([^)-]+)\)', derivrplEq, eqCons)

eqCons = re.sub(r'\(([^()]+)\)\*\*\(([^()]+)\)', r'(pow(\1, \2))', eqCons)
eqCons = re.sub(r'([\w\.]+)\*\*\(([^()]+)\)', r'(pow(\1, \2))', eqCons)
eqCons = re.sub(r'\(([^()]+)\)\*\*([\w\.]+)', r'(pow(\1, \2))', eqCons)
eqCons = re.sub(r'([\w\.]+)\*\*([\w\.]+)', r'(pow(\1, \2))', eqCons)
#
#eqCons = re.sub(r'\(([^()]*)\)\*\*\(([^()]*)\)', r'(pow(\1, \2))', eqCons)
#eqCons = re.sub(r't\*\*([^()\s])', r'(pow(t, \1))', eqCons)
#eqCons = re.sub(r'Tp\*\*([^()\s])', r'(pow(Tp, \1))', eqCons)
#eqCons = re.sub(r'\(([^()]*)\)\*\*([^()\s])', r'(pow(\1, \2))', eqCons)
#eqCons = re.sub(r'([^()])\*\*([^()\s])', r'(pow(\1, \2))', eqCons)

offset = 0
m = re.search(r'abs|sqrt|DiracDelta|sign', eqCons)
while m != None:
	eqCons = addParenthesis(m, eqCons, offset)
	offset += m.end()+1 # +1 for parenthesis
	m = re.search(r'abs|sqrt|DiracDelta|sign', eqCons[offset:])

offset = 0
m = re.search(r'\)\*\*([\w\.]+)', eqCons)
while m != None:
	#print 'm.end' , m.end()
	eqCons = rplComplicPowL(m, eqCons, offset)
	offset += m.end()+5 # +1 for parenthesis
	#print eqCons[offset:]
 	m = re.search(r'\)\*\*([\w\.]+)', eqCons[offset:])

offset = 0
m = re.search(r'[\w\.]+\*\*\(', eqCons)
while m != None:
	#print 'm.end' , m.end()
	eqCons = rplComplicPowD(m, eqCons, offset)
	offset += m.end()+7 # +1 for parenthesis
	#print eqCons[offset:]
 	m = re.search(r'[\w\.]+\*\*\(', eqCons[offset:])

offset = 0
m = re.search(r'\)\*\*(\([^()]+\))', eqCons)
while m != None:
	#print 'm.end' , m.end()
	eqCons = rplComplicPowL(m, eqCons, offset)
	offset += m.end()+5 # +1 for parenthesis
	#print eqCons[offset:]
 	m = re.search(r'\)\*\*(\([^()]+\))', eqCons[offset:])

offset = 0
m = re.search(r'\([^()]+\)\*\*\(', eqCons)
while m != None:
	#print 'm.end' , m.end()
	eqCons = rplComplicPowD(m, eqCons, offset)
	offset += m.end()+7 # +1 for parenthesis
	#print eqCons[offset:]
 	m = re.search(r'\([^()]+\)*\*\(', eqCons[offset:])

eqCons = re.sub(r'Matrix\(\[', r'J <<', eqCons)
eqCons = re.sub(r'\]\]\)', r';', eqCons)
eqCons = re.sub(r'\[', r'', eqCons)
eqCons = re.sub(r'\]', r'', eqCons)

def idxrplcer(matchobj):
	nIdx = str(int(matchobj.group(1))-1)
	return 'X['+nIdx+']'

eqCons = re.sub(r'X1_([0-9]*)', idxrplcer, eqCons)

#print eqCons

f.close()
f = open(str(sys.argv[1])[0:-3] + 'cpp', 'w')
f.write(eqCons)