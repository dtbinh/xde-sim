%% INITIALIZATIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

pkg load symbolic;
pkg load nurbs;

nk = 4; % number internal knots
l = 2; % derivative order needed

% MAXIMA another symbolic computation system

spld = l + 2; % spline order
d = spld - 1; % here spline order is one less the value used in C++ code (eigen spline)
ncp = nk + spld - 1; % number of control points

%% SYMBOLIC VARIABLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X = sym('X', [1 ncp*2]);
for i = 1:ncp*2
  assume(X(i), 'real');
end

Tp = sym('Tp', 'real', 'positive');
knots = [0 0 0 0 .25*Tp .5*Tp .75*Tp Tp Tp Tp Tp]; % TODO call genknots

t = sym('t', 'real', 'positive');

C = reshape(X, [2 ncp]);

%% CREATE B-spline from knots and C %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[dC,dknots] = bspderivative(d, C, knots);
dC = simplify(dC);
dknots = simplify(dknots);
[ddC,ddknots] = bspderivative(d-1, dC, dknots);
ddC = simplify(ddC);
ddknots = simplify(ddknots);
[dddC,dddknots] = bspderivative(d-2, ddC, ddknots);
dddC = simplify(dddC);
dddknots = simplify(dddknots);

z = bspevaluation(d, C, knots, t);
dz = bspevaluation(d-1, dC, dknots, t);
ddz = bspevaluation(d-2, ddC, ddknots, t);
dddz = bspevaluation(d-3, dddC, dddknots, t);

%% CREATE CONSTRAINTS FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

g_pos = [z(1) z(2) atan2(dz(2), dz(1))];

g_vel = [norm(dz) (dz(1)*ddz(2) - dz(2)*ddz(1))/(dz(1)^2 + dz(2)^2)];

g_absvel = [norm(dz) abs((dz(1)*ddz(2) - dz(2)*ddz(1))/(dz(1)^2 + dz(2)^2))];

dv = (dz(1)*ddz(1) + dz(2)*ddz(2))/norm(dz);
domega = (ddz(1)*ddz(2)+dddz(2)*dz(1)-(ddz(2)*ddz(1)+dddz(1)*dz(2)))*norm(dz)^2 - 2*(dz(1)*ddz(2)-dz(2)*ddz(1))*norm(dz)*dv;

g_acc = [dv domega];

g_absacc = [abs(dv) abs(domega)];

o_pos = [sym('ox', 'real') sym('oy', 'real')];

dobst = norm(z'-o_pos);

%% COMPUTE SYMBOLIC JACOBIANS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic();

disp('g_pos...');
J_pos = jacobian(g_pos, X);
ccodeJ_pos = ccode(J_pos);
filename = "qJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_pos);
fclose (fid);
disp('done');

disp('g_vel...');
J_vel = jacobian(g_vel, X);
ccodeJ_vel = ccode(J_vel);
filename = "dqJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_vel);
fclose (fid);
disp('done');

disp('g_absvel...');
J_absvel = jacobian(g_absvel, X);
ccodeJ_absvel = ccode(J_absvel);
filename = "absdqJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_absvel);
fclose (fid);
disp('done');

disp('g_acc...');
J_acc = jacobian(g_acc, X);
ccodeJ_acc = ccode(J_acc);
filename = "ddqJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_acc);
fclose (fid);
disp('done');

disp('g_absacc...');
J_absacc = jacobian(g_absacc, X);
ccodeJ_absacc = ccode(J_absacc);
filename = "absddqJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_absacc);
fclose (fid);
disp('done');

disp('g_dobst...');
J_droundobs = jacobian([dobst], X);
ccodeJ_droundobs = ccode(J_droundobs);
filename = "distRObsJac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ_droundobs);
fclose (fid);
disp('done');

disp(toc());