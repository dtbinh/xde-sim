#include "aiv/pathplanner/PathPlannerRecedingHoriz_IPOPT.hpp"
//#include "aiv/pathplanner/PathPlannerRecedingHoriz.hpp"
#include "aiv/pathplanner/FlatoutputMonocycle.hpp"
#include <IpIpoptApplication.hpp>
#include <IpSolveStatistics.hpp>
#include <nlopt.h>
#include <omp.h>
#include <boost/foreach.hpp>
#include <algorithm>

#include <IpTNLP.hpp>
#include "aiv/pathplanner/FlatoutputMonocycle.hpp"
#include <adolc.h>

#define foreach_ BOOST_FOREACH

#ifndef HAVE_CONFIG_H
#define HAVE_CONFIG_H
#endif

using namespace Ipopt;

namespace aiv
{

	//typedef Eigen::Spline< double, aiv::PathPlannerRecedingHorizIpopt::splDim, aiv::PathPlannerRecedingHorizIpopt::splDegree > MySpline;

	PathPlannerRecedingHorizIpopt::PathPlannerRecedingHorizIpopt(std::string name, double updateTimeStep)
		: PathPlanner(name)
		, updateTimeStep(updateTimeStep)
		, updateCallCntr(0)
		, lastStepMinDist(0.5)
		, xTol(0.001)
		, fTol(0.001)
		, eqTol(0.001)
		, ineqTol(0.001)
		, lastMaxIteration(25)
		, firstMaxIteration(50)
		, interMaxIteration(20)
		, conflictFreePathDeviation(4.0)
		, interRobotSafetyDist(0.1)
		, nextVelocityRef(Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 >::Zero())
		, nextPoseRef(Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 >::Zero())
		, planStage(INIT)
		, ongoingPlanIdx(-1)
		, executingPlanIdx(-1)
		, standAlone(true)
		, lastPlanComputed(false)
		, optimizerType("SLSQP")
		, h(0.0001)
	{
		this->planOngoingMutex.initialize();
		this->opt_log.open("optlog/opt_log.txt");
		this->eq_log.open("optlog/eq_log.txt");
	}

	PathPlannerRecedingHorizIpopt::~PathPlannerRecedingHorizIpopt()
	{
		this->opt_log.close();
		this->eq_log.close();
	}

	void PathPlannerRecedingHorizIpopt::init(
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
		double compHorizon,
		double refPlanHorizon,
		unsigned noTimeSamples,
		unsigned noIntervNonNull)
	{
		this->initPose = initPose;
		this->initFlat = aiv::FlatoutputMonocycle::poseToFlat(this->initPose);
		this->latestFlat = this->initFlat;
		this->initVelocity = initVelocity;
		this->targetedPose = targetedPose;

		this->targetedFlat = aiv::FlatoutputMonocycle::poseToFlat(this->targetedPose);
		this->targetedVelocity = targetedVelocity;
		this->maxVelocity = maxVelocity;
		this->mindAcceleration = false;

		this->compHorizon = compHorizon; // computation horizon
		this->refPlanHorizon = refPlanHorizon; // planning horizon
		this->finalPlanHorizon = refPlanHorizon; // planning horizon
		this->planHorizon = refPlanHorizon; // planning horizon
		this->noTimeSamples = noTimeSamples; // number of  time samples taken within a planning horizon
		this->noIntervNonNull = noIntervNonNull; // number of non null knots intervals
		this->noCtrlPts = noIntervNonNull + this->splDegree;
		this->maxStraightDist = refPlanHorizon * maxVelocity(aiv::FlatoutputMonocycle::linSpeedIdx);

		this->latestFlat = this->initFlat;
		this->latestPose = initPose;
		this->initPoseForCurrPlan = initPose;
		this->latestVelocity = initVelocity;

		opt_log << "init: PP Initializing..." << std::endl;
		//plTimer.ResetTime();
	}

	void PathPlannerRecedingHorizIpopt::init(
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &initPose, // x, y, theta
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &initVelocity, // v, w
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > &targetedPose, // x, y, theta
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &targetedVelocity, // v, w
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxVelocity, // v, w
		const Eigen::Matrix< double, aiv::FlatoutputMonocycle::velocityDim, 1 > &maxAcceleration, // dv, dw
		double compHorizon,
		double refPlanHorizon,
		unsigned noTimeSamples,
		unsigned noIntervNonNull)
	{
		init(initPose, initVelocity, targetedPose, targetedVelocity, maxVelocity, compHorizon, refPlanHorizon, noTimeSamples, noIntervNonNull);
		this->maxAcceleration = maxAcceleration;
		opt_log << "init: Using acceleration." << std::endl;
	}

	void PathPlannerRecedingHorizIpopt::setOption(std::string optionName, std::string optionValue)
	{
		if (optionName == "optimizerType")
		{
			this->optimizerType = optionValue;
			opt_log << "init: Using \"" << optionValue << "\" optimizer" << std::endl;
			std::cout << "init: Using \"" << optionValue << "\" optimizer" << std::endl;
		}
	}

	void PathPlannerRecedingHorizIpopt::setOption(std::string optionName, double optionValue)
	{
		if (optionName == "lastStepMinDist")
		{
			this->lastStepMinDist = optionValue;
		}
		else if (optionName == "xTol")
		{
			this->xTol = optionValue;
		}
		else if (optionName == "fTol")
		{
			this->fTol = optionValue;
		}
		else if (optionName == "eqTol")
		{
			this->eqTol = optionValue;
		}
		else if (optionName == "ineqTol")
		{
			this->ineqTol = optionValue;
		}
		else if (optionName == "conflictFreePathDeviation")
		{
			this->conflictFreePathDeviation = optionValue;
		}
		else if (optionName == "interRobotSafetyDist")
		{
			this->interRobotSafetyDist = optionValue;
		}
		else if (optionName == "lastMaxIteration")
		{
			this->lastMaxIteration = unsigned(optionValue);
		}
		else if (optionName == "firstMaxIteration")
		{
			this->firstMaxIteration = unsigned(optionValue);
		}
		else if (optionName == "interMaxIteration")
		{
			this->interMaxIteration = unsigned(optionValue);
		}
		else if (optionName == "offsetTime")
		{
			this->firstPlanTimespan = optionValue;
		}
		else if (optionName == "waitPlanning")
		{
			this->waitPlanning = bool(optionValue);
		}
	}

	void PathPlannerRecedingHorizIpopt::update()//const Eigen::Displacementd & realPose, const Eigen::Twistd &realVelocity)
	{

		double currentPlanningTime = updateTimeStep*updateCallCntr;
		++updateCallCntr;

		double evalTime = std::max(std::min(((currentPlanningTime - (std::max((this->executingPlanIdx), 0)*this->compHorizon)) / this->planHorizon), 1.), 0.);

		// --- REAL COMPUTATION
		
		if (planStage != DONE && planStage != FINAL) //only necessery if the planning stage is INIT or INTER
		{

			/*std::cout << "----------------------------------------------------" <<
				evalTime << currentPlanningTime << executingPlanIdx <<
				"----------------------------------------------------" << std::endl;*/

			// First update call
			if (this->ongoingPlanIdx == -1)
			{
				this->planOngoingMutex.lock();
				planThread = boost::thread(&PathPlannerRecedingHorizIpopt::plan, this); // Do P0
				++this->ongoingPlanIdx;
				opt_log << "update: _______ (C1) Spawn the first plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;
			}

			// If we are in P0 stage
			else if (this->ongoingPlanIdx == 0 && currentPlanningTime > firstPlanTimespan) // Time so robot touch the floor
			{
				std::cout << "firstPlanTimespan " <<  firstPlanTimespan << std::endl;
				if (!this->planOngoingMutex.try_lock()) // We are supposed to get this lock
				{
					// "kill" planning thread putting something reasonable in the aux spline
					// OR pause the simulation for a while, waiting for the plan thread to finish (completly unreal) => planThread.join()
					opt_log << "update: ####### HECK! Plan didn't finish before computing time expired #######" << std::endl;
					std::cout << "update: ####### HECK! Plan didn't finish before computing time expired #######" << std::endl;
					if (waitPlanning == true)
					{
						planThread.join();
					}
					else
					{
						planThread.interrupt();
					}
					this->planOngoingMutex.lock();
				}

				planStage = INTER;

				// update solution spline with the auxliar spline find in planning 0;
				// no need to lock a mutex associated to the auxiliar spline because we are sure there is no ongoing planning
				this->solSpline = this->auxSpline;
				this->finalPoseForFuturePlan = this->latestPose;

				/*if (this->planStage == FINAL)
				{
					this->lastPlanExec = true;
					this->planHorizon = this->finalPlanHorizon;
					this->planOngoingMutex.unlock();
				}
				else
				{*/

				planThread = boost::thread(&PathPlannerRecedingHorizIpopt::plan, this); // Do P1
				++this->ongoingPlanIdx;
				opt_log << "update: _______ (C2) Spawn the second plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;

				//}
				// P0 will begin to be executed
				++this->executingPlanIdx;

				// Reset update call counter so evaluation time be corret
				updateCallCntr = 0;
				currentPlanningTime = 0.0;
				evalTime = 0.0;
			}

			// If the robot started to execute the motion:
			else if (this->ongoingPlanIdx > 0 && evalTime >= this->compHorizon / this->planHorizon)
			{
				//std::cout << "Eval time before fix " << evalTime << std::endl;
				//std::cout << "Current before fix " << secCurrentTime << std::endl;
				//std::cout << "CompHorizon " << this->compHorizon << std::endl;
				evalTime -= this->compHorizon / this->planHorizon; // "Fix" evalTime
				//std::cout << "Eval time fixed " << evalTime << std::endl;

				if (!this->planOngoingMutex.try_lock()) // We are supposed to get this lock
				{
					opt_log << "update: ####### HECK! Plan didn't finish before computing time expired #######" << std::endl;
					std::cout << "update: ####### HECK! Plan didn't finish before computing time expired #######" << std::endl;
					// "kill" planning thread putting something reasonable in the aux spline
					// OR pause the simulation for a while, waiting for the plan thread to finish (completly unreal) => planThread.join()
					//xde::sys::Timer::Sleep( 0.02 );
					if (waitPlanning == true)
					{
						planThread.join();
					}
					else
					{
						planThread.interrupt();
					}
					this->planOngoingMutex.lock();
				}
				// Now we are sure that there is no ongoing planning!

				// update solution spline with the auxliar spline;
				// no need to lock a mutex associated to the auxiliar spline because we are sure there is no ongoing planning

				this->solSpline = this->auxSpline; // update solution
				this->initPoseForCurrPlan = this->finalPoseForFuturePlan; // update base pose
				this->finalPoseForFuturePlan = this->latestPose; // get latest position found by the plan that just ended (will be the next base pos)

				if (lastPlanComputed)
				{
					planStage = FINAL;
					this->planHorizon = this->finalPlanHorizon;
					this->planOngoingMutex.unlock();
					opt_log << "update: !!!!! Now goint to execute last plan !!!!!" << std::endl;
				}
				else
				{
					// plan next section!
					planThread = boost::thread(&PathPlannerRecedingHorizIpopt::plan, this); // Do PX with X in (1, 2, ..., indefined_finit_value)
					++this->ongoingPlanIdx;
					opt_log << "update: _______ (C3) Spawn new plan thread!!! ________ " << this->ongoingPlanIdx << std::endl;
				}
				++this->executingPlanIdx;
			}
		}
		else if (planStage == FINAL && evalTime >= 1.0)
		{
			planStage = DONE;
		}

		// --- APPARENT UPDATE

		if (planStage == INIT)
		{
			nextPoseRef = initPose;
			nextVelocityRef = initVelocity;
		}
		else if (planStage == DONE)
		{
			std::cout << "plan STAGE DONE" << std::endl;
			nextPoseRef = targetedPose;
			nextVelocityRef = targetedVelocity;
		}
		else //INTER or FINAL
		{
			// just use solSpline to get the nextReferences values
			Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg + 1 > derivFlat =
				solSpline.derivatives(
					evalTime*planHorizon, aiv::FlatoutputMonocycle::flatDerivDeg
					).block< aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg + 1 >(1, 0);

			this->nextPoseRef = aiv::FlatoutputMonocycle::flatToPose(derivFlat);

			this->nextPoseRef.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) =
				this->nextPoseRef.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) +
				this->initPoseForCurrPlan.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

			this->nextVelocityRef = aiv::FlatoutputMonocycle::flatToVelocity(derivFlat);
		}

		return;
	}

	// update auxSpline
	void PathPlannerRecedingHorizIpopt::plan()
	{
		//std::cout << "CTROL FROM PLAN\n" << this->auxSpline.ctrls() << std::endl;
		//boost::this_thread::sleep(boost::posix_time::milliseconds(100));
		/* INITIALIZATION OF CTRL PTS
		_______________________________________*/
		// Use auxSpline with old solution to initiate the new one
		// Estimate the position of the point
		//std::cout << "Max straigth dist" << this->maxStraightDist << std::endl << std::endl << std::endl;

		Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > remainingDistVectorUni = (this->targetedFlat - this->latestFlat);
		//Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > remainingDistVectorUni =
		//    ((Eigen::Vector2d() << .5, 4).finished() - this->latestFlat);
		double remainingDist = remainingDistVectorUni.norm();
		remainingDistVectorUni /= remainingDist;
		Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, 1 > lastCtrlPt = this->maxStraightDist*remainingDistVectorUni;

		if (remainingDist < this->lastStepMinDist + this->compHorizon*this->initVelocity[aiv::FlatoutputMonocycle::linSpeedIdx])
		{
			//exit(0);
			//system("pause");
			lastPlanComputed = true;
			//estimate time
			this->finalPlanHorizon = this->refPlanHorizon/2; //TODO change the estimate
		}

		opt_log << "plan: PLAN STAGE: " << planStage << std::endl;
		/*std::cout << direction << std::endl;
		std::cout << direction.norm() << std::endl;*/

		// Interpolation time
		Eigen::RowVectorXd interpTime;
		if (lastPlanComputed)
			interpTime = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, this->finalPlanHorizon);
		else
			interpTime = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, this->refPlanHorizon);

		// Interpolation points ( noCtrlPts points )
		MySpline::ControlPointVectorType points(this->splDim, this->noCtrlPts);
		points.row(0) = interpTime;

		/*double bearing;
		double angSpeed;
		double linSpeed;*/

		switch (lastPlanComputed) //TODO
		{
		case false:
			if (planStage == INIT)
			{
				/*for ( auto i = 1; i < splDim; ++i )
				{
				  for ( auto j = 0; j < noCtrlPts; ++j )
				  {
					points(i,j) = -100.0 + (double)rand() / RAND_MAX * (200.0);
				  }
				}*/
				for (auto i = 1; i < splDim; ++i)
				{
					points.row(i) = Eigen::RowVectorXd::LinSpaced(noCtrlPts, 0.0, lastCtrlPt(i - 1));
				}
				/*bearing = acos(remainingDistVectorUni.x())-latestPose(2,0);
				linSpeed = refPlanHorizon/noCtrlPts * maxAcceleration.x();
				angSpeed = refPlanHorizon/noCtrlPts * maxAcceleration.y();*/ //refPlanHorizon/noCtrlPts*bearing/(2*3.1415)*angSpeed/2.+
				//points(1,1) = cos(latestPose(2,0))*(refPlanHorizon/noCtrlPts*maxVelocity.x()/2.) + points(1,0);// + points(1,1))/2.;
				//points(2,1) = sin(latestPose(2,0))*(refPlanHorizon/noCtrlPts*maxVelocity.x()/2.) + points(2,0);// + points(2,1))/2.;
				////std::cout << "___________________PTSinit________________________\n" << points.block<2,1>(0,1) << std::endl;
			}
			else
			{
				/*for ( auto i = 1; i < splDim; ++i )
				{
				for ( auto j = 0; j < noCtrlPts; ++j )
				{
				points(i,j) = -100.0 + (double)rand() / RAND_MAX * (200.0);
				}
				}*/
				for (auto i = 1; i < splDim; ++i)
				{
					points.row(i) = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, lastCtrlPt(i - 1));
				}
			}
			break;
		case true:
			for (auto i = 1; i < splDim; ++i)
			{
				points.row(i) = Eigen::RowVectorXd::LinSpaced(this->noCtrlPts, 0.0, lastCtrlPt(i - 1));
			}
			break;
		}

		// Get chords lengths from interpolation time
		MySpline::KnotVectorType chordLengths;
		Eigen::ChordLengths(interpTime, chordLengths);

		// Call fitting static method
		this->auxSpline = Eigen::SplineFitting<MySpline>::Interpolate(points, splDegree, chordLengths);

		//std::cout << this->auxSpline.ctrls() << std::endl;
		//system("pause");

		/*Eigen::ArrayXd optParam(this->splDim-1, this->noCtrlPts);
		optParam = this->auxSpline.ctrls().block(1, 0, this->splDim-1, this->noCtrlPts);
		for ( unsigned i = 0; i < this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim; ++i )
		{
		  std::cout << optParam(i/(this->splDim-1), i%(this->splDim-1)) << std::endl;
		}*/

		/* CALL OPT SOLVER (in stand alone mode)
		_______________________________________*/

		this->standAlone = true;

		this->solveOptPbl();

		/* GET RESULTS
		_______________________________________*/


		/* UPDATES
		_______________________________________*/
		// update latest flatoutput and pose for the new planning

		Eigen::Matrix< double, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg + 1 > derivFlat =
			auxSpline.derivatives(
				this->compHorizon, aiv::FlatoutputMonocycle::flatDerivDeg
				).block< aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg + 1 >(1, 0);

		this->latestFlat += derivFlat.col(0);
		//std::cout << "__________\nLatest flat\n" << this->latestFlat << "\n_____________\n";

		Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > latestPoseIncrement;
		Eigen::Matrix< double, aiv::FlatoutputMonocycle::poseDim, 1 > auxLatestPose;

		auxLatestPose = this->latestPose;

		this->latestPose = aiv::FlatoutputMonocycle::flatToPose(derivFlat);
		//std::cout << "__________\nflatToPose call on deriv at tc/tp\n" << this->latestPose << "\n_____________\n";
		this->latestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) +=
			auxLatestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

		this->latestVelocity = aiv::FlatoutputMonocycle::flatToVelocity(derivFlat);

		//switch (this->planStage)
		//{
		//case FINAL:
		//	break;
		//case INIT:
		//	this->planStage = INTER;
		//	break;
		//	// REDO TIME AND KNOTS
		//}
		opt_log << "plan:\n__________\nLATEST POSE\n" << this->latestPose << "\n_____________\n";
		//boost::this_thread::sleep(boost::posix_time::milliseconds(1000));
		this->planOngoingMutex.unlock();
		return;
	}

	void PathPlannerRecedingHorizIpopt::solveOptPbl()
	{
		unsigned nParam;
		unsigned nEq;
		unsigned nIneq;
		double(*objF) (unsigned, const double *, double *, void *);
		void(*eqF) (unsigned, double *, unsigned, const double*, double*, void*);
		void(*ieqF) (unsigned, double *, unsigned, const double*, double*, void*);

		double *optParam;
		double *tolEq;
		double *tolIneq;

		//RecHorNLP* myNLP;

		switch (lastPlanComputed)
		{
		case false:

			objF = PathPlannerRecedingHorizIpopt::objectFunc;
			eqF = PathPlannerRecedingHorizIpopt::eqFunc;
			ieqF = PathPlannerRecedingHorizIpopt::ineqFunc;
			nParam = this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim;
			nEq = aiv::FlatoutputMonocycle::poseDim + aiv::FlatoutputMonocycle::velocityDim;
			nIneq = aiv::FlatoutputMonocycle::velocityDim * (this->noTimeSamples - 1) +
				aiv::FlatoutputMonocycle::accelerationDim * (this->noTimeSamples);
			//std::cout << "nIEQ: " << nIneq << std::endl;

			optParam = new double[nParam];
			for (unsigned i = 0; i < nParam; ++i)
			{
				optParam[i] = this->auxSpline.ctrls()(i % (this->splDim - 1) + 1, i / (this->splDim - 1));
			}

			tolEq = new double[nEq];
			for (unsigned i = 0; i < nEq; ++i)
			{
				tolEq[i] = this->eqTol;
			}

			tolIneq = new double[nIneq];
			for (unsigned i = 0; i < nIneq; ++i)
			{
				tolIneq[i] = this->ineqTol;
			}

			break;
		case true:
			//system("pause");
			objF = PathPlannerRecedingHorizIpopt::objectFuncLS;
			eqF = PathPlannerRecedingHorizIpopt::eqFuncLS;
			ieqF = PathPlannerRecedingHorizIpopt::ineqFuncLS;
			nParam = this->noCtrlPts*aiv::FlatoutputMonocycle::flatDim + 1;
			nEq = (aiv::FlatoutputMonocycle::poseDim + aiv::FlatoutputMonocycle::velocityDim) * 2;
			nIneq = aiv::FlatoutputMonocycle::velocityDim * (this->noTimeSamples - 2) +
				aiv::FlatoutputMonocycle::accelerationDim * (this->noTimeSamples);

			optParam = new double[nParam];
			optParam[0] = this->finalPlanHorizon;
			for (unsigned i = 1; i < nParam; ++i)
			{
				optParam[i] = this->auxSpline.ctrls()((i - 1) % (this->splDim - 1) + 1, (i - 1) / (this->splDim - 1));
			}

			tolEq = new double[nEq];
			for (unsigned i = 0; i < nEq; ++i)
			{
				tolEq[i] = this->eqTol;
			}

			tolIneq = new double[nIneq];
			for (unsigned i = 0; i < nIneq; ++i)
			{
				tolIneq[i] = this->ineqTol;
			}
			break;
		}
		opt_log << "solve: nParam " << nParam << "; nEq " << nEq << "; nIneq " << nIneq << std::endl;
		std::cout << "solve: nParam " << nParam << "; nEq " << nEq << "; nIneq " << nIneq << std::endl;

		// OPTIMIZE
		std::cout << "_____________________________________________________________________" << std::endl;
		std::cout << "|__________________________ Optimize CALL __________________________|" << std::endl;
		std::cout << "|___________________________________________________________________|" << std::endl;

		if (optimizerType == "NONE")
		{

		}
		else if (optimizerType != "IPOPT")
		{

			if (!lastPlanComputed)
			//if(true)
			{
				myNLP = new RecHorNLP(nParam, nEq, nIneq, noCtrlPts, noTimeSamples, auxSpline, finalPlanHorizon,
					targetedPose, latestPose, latestVelocity, maxVelocity, maxAcceleration, NULL);
			}
			else
			{
				std::cout << "Build Term NLP" << std::endl;
				opt_log << "Build Term NLP" << std::endl;
				myNLP = new TermNLP(nParam, nEq, nIneq, noCtrlPts, noTimeSamples, auxSpline, targetedPose,
					latestPose, targetedVelocity, latestVelocity, maxVelocity, maxAcceleration, NULL);
				std::cout << "Done building NLP" << std::endl;
			}

			int gni_n, gni_m, gni_nn_jac_g, gni_nnz_h_lag;
			Ipopt::TNLP::IndexStyleEnum gni_index_stype;
			std::cout << "call nlp info" << std::endl;
			myNLP->get_nlp_info(gni_n, gni_m, gni_nn_jac_g, gni_nnz_h_lag, gni_index_stype);
			std::cout << "done calling nlp info" << std::endl;

			nlopt_opt opt;

			if (optimizerType == "COBYLA")
			{
				opt = nlopt_create(NLOPT_LN_COBYLA, nParam);
			}
			else if (optimizerType == "SLSQP")
			{
				opt = nlopt_create(NLOPT_LD_SLSQP, nParam);
			}

			nlopt_set_xtol_rel(opt, this->xTol);

			nlopt_set_min_objective(opt, objF, this);
			nlopt_add_equality_mconstraint(opt, nEq, eqF, this, tolEq);
			nlopt_add_inequality_mconstraint(opt, nIneq, ieqF, this, tolIneq);

			double minf;
			std::cout << "Call optimizer" << std::endl;
			int status;
			//if (!lastPlanComputed)
			//{
			status = nlopt_optimize(opt, optParam, &minf);
			//status = 1;
			//}
			//else
			//{
			//	status = 1;
			//}
			std::cout << "Optimizer return" << std::endl;

			/*
			NLOPT_SUCCESS = 1
			Generic success return value.
			NLOPT_STOPVAL_REACHED = 2
			Optimization stopped because stopval (above) was reached.
			NLOPT_FTOL_REACHED = 3
			Optimization stopped because ftol_rel or ftol_abs (above) was reached.
			NLOPT_XTOL_REACHED = 4
			Optimization stopped because xtol_rel or xtol_abs (above) was reached.
			NLOPT_MAXEVAL_REACHED = 5
			Optimization stopped because maxeval (above) was reached.
			NLOPT_MAXTIME_REACHED = 6
			Optimization stopped because maxtime (above) was reached.
			[edit]
			Error codes (negative return values)
			NLOPT_FAILURE = -1
			Generic failure code.
			NLOPT_INVALID_ARGS = -2
			Invalid arguments (e.g. lower bounds are bigger than upper bounds, an unknown algorithm was specified, etcetera).
			NLOPT_OUT_OF_MEMORY = -3
			Ran out of memory.
			NLOPT_ROUNDOFF_LIMITED = -4
			Halted because roundoff errors limited progress. (In this case, the optimization still typically returns a useful result.)
			NLOPT_FORCED_STOP = -5
			Halted because of a forced termination: the user called nlopt_force_stop(opt) on the optimization�s nlopt_opt object opt from the user�s objective function or constraints.
			*/

			SolverReturn status2;

			myNLP->finalize_solution(status2,
				nParam, optParam, NULL, NULL,
				nEq + nIneq, NULL, NULL,
				minf,
				NULL,
				NULL);
			if (status < 0) {
				std::cout << "solve: _____________________________________________nlopt failed!\n";
				opt_log << "solve: _____________________________________________nlopt failed!\n";
				opt_log << "solve: with error: " << status << std::endl;
				std::cout << "solve: with error: " << status << std::endl;
				//opt_log << "objectif func value: " << minf << std::endl;
			}
			//opt_log << "objectif func value: " << minf << std::endl;

			delete myNLP;
		}
		else if (optimizerType == "IPOPT")
		{

			SmartPtr<TNLP> smartMyNLP;

			if (this->planStage != FINAL)
			{
				smartMyNLP = new RecHorNLP(nParam, nEq, nIneq, noCtrlPts, noTimeSamples, auxSpline, finalPlanHorizon,
					targetedPose, latestPose, latestVelocity, maxVelocity, maxAcceleration, optParam);
			}
			else
			{
				smartMyNLP = new TermNLP(nParam, nEq, nIneq, noCtrlPts, noTimeSamples, auxSpline, targetedPose,
					latestPose, targetedVelocity, latestVelocity, maxVelocity, maxAcceleration, optParam);
			}

			// Create an instance of the IpoptApplication
			//
			// We are using the factory, since this allows us to compile this
			// example with an Ipopt Windows DLL
			SmartPtr<IpoptApplication> app = IpoptApplicationFactory();

			/*
			tol
			Desired convergence tolerance (relative).
			Determines the convergence tolerance for the algorithm.
			The algorithm terminates successfully, if the (scaled) NLP error becomes smaller than this value,
			and if the (absolute) criteria according to "dual_inf_tol", "primal_inf_tol", and "compl_inf_tol"
			are met. (This is epsilon_tol in Eqn. (6) in implementation paper). See also "acceptable_tol"
			as a second termination criterion. Note, some other algorithmic features also use this quantity
			to determine thresholds etc. The valid range for this real option is  $ 0 < {\tt tol } < {\tt +inf}$
			and its default value is  $ 1 \cdot 10^{-08}$ .
			*/

			app->Options()->SetNumericValue("tol", xTol);

			//app->Options()->SetNumericValue("constr_viol_tol", ineqTol);

			/*app->Options()->SetNumericValue("primal_inf_tol", 1e20);

			app->Options()->SetNumericValue("dual_inf_tol", 1e20);*/

			/*Maximum number of iterations.
			The algorithm terminates with an error message if the number of iterations exceeded this number.
			The valid range for this integer option is $ 0 \le {\tt max\_iter } < {\tt +inf}$ and its default value is $ 3000$ .
			*/

			app->Options()->SetIntegerValue("max_iter", 1000);

			app->Options()->SetIntegerValue("print_level", 0);

			//app->Options()->SetStringValue("mu_strategy", "adaptive");
			app->Options()->SetStringValue("output_file", "optlog/ipopt.out");

			// Initialize the IpoptApplication and process the options
			ApplicationReturnStatus status;
			status = app->Initialize();
			if (status != Solve_Succeeded)
			{
				std::cout << std::endl << std::endl << "*** Error during initialization!" << std::endl;
				// TODO do something with solution
				return;
			}

			status = app->OptimizeTNLP(smartMyNLP);

			if (status == Solve_Succeeded)
			{
				// Retrieve some statistics about the solve
				Index iter_count = app->Statistics()->IterationCount();
				std::cout << std::endl << std::endl << "*** The problem solved in " << iter_count << " iterations!" << std::endl;

				Number final_obj = app->Statistics()->FinalObjective();
				std::cout << std::endl << std::endl << "*** The final value of the objective function is " << final_obj << '.' << std::endl;
			}

			//smartMyNLP->get_x( optParam );

			smartMyNLP.~SmartPtr();
		}

		std::ofstream arquivo;
		arquivo.open("optlog/xiter.csv", std::fstream::app);
		arquivo << "___________________________________________________" << std::endl;
		arquivo.close();
		arquivo.open("optlog/geqiter.csv", std::fstream::app);
		arquivo << "___________________________________________________" << std::endl;
		arquivo.close();
		arquivo.open("optlog/gieqiter.csv", std::fstream::app);
		arquivo << "___________________________________________________" << std::endl;
		arquivo.close();
		arquivo.open("optlog/citer.csv", std::fstream::app);
		arquivo << "___________________________________________________" << std::endl;
		arquivo.close();


		MySpline::ControlPointVectorType ctrlPts(this->splDim, this->noCtrlPts);

		MySpline::KnotVectorType knots;

		//update spline
		switch (lastPlanComputed)
		{
		case false:
			ctrlPts.row(0) = this->auxSpline.ctrls().row(0);

			std::cout << "\nKnots:";
			std::cout << "\n__________________________\n" << this->auxSpline.knots() << "\n__________________________\n" << std::endl;

			std::cout << "\nTime:";
			std::cout << "\n__________________________\n" << ctrlPts.row(0) << "\n__________________________\n" << std::endl;

			opt_log << "\nKnots:";
			opt_log << "\n__________________________\n" << this->auxSpline.knots() << "\n__________________________\n" << std::endl;

			opt_log << "\nTime:";
			opt_log << "\n__________________________\n" << ctrlPts.row(0) << "\n__________________________\n" << std::endl;

			for (unsigned i = 0; i < nParam; ++i)
			{
				// get ctrl pts matrix => p1x, p1y, p2x, p2y...
				ctrlPts(i % (this->splDim - 1) + 1, i / (this->splDim - 1)) = optParam[i];
			}

			knots = this->auxSpline.knots();
			//std::cout << knots << std::endl << std::endl;
			this->auxSpline.~MySpline();
			new (&this->auxSpline) MySpline(knots, ctrlPts);

			break;
		case true:
			// get new knots TODO
			knots = genKnots(0.0, 1.0, true);
			std::cout << "\nKnots:";
			opt_log << "\nKnots:";
			std::cout << "\n__________________________\n" << knots << "\n__________________________\n" << std::endl;
			opt_log << "\n__________________________\n" << knots << "\n__________________________\n" << std::endl;


			// get new time
			ctrlPts.row(0) = Eigen::Array< double, 1, Eigen::Dynamic >::LinSpaced(this->noCtrlPts, 0.0, optParam[0]);
			this->finalPlanHorizon = ctrlPts(0, this->noCtrlPts - 1);


			std::cout << "\nTime:";
			std::cout << "\n__________________________\n" << ctrlPts.row(0) << "\n__________________________\n" << std::endl;
			opt_log << "\nTime:";
			opt_log << "\n__________________________\n" << ctrlPts.row(0) << "\n__________________________\n" << std::endl;

			// get the rest of the ctrl pts
			for (unsigned i = 1; i < nParam; ++i)
			{
				// get ctrl pts matrix => p1x, p1y, p2x, p2y...
				ctrlPts((i - 1) % (this->splDim - 1) + 1, (i - 1) / (this->splDim - 1)) = optParam[i];
			}

			//knots = this->auxSpline.knots();
			//std::cout << knots << std::endl << std::endl;
			this->auxSpline.~MySpline();
			new (&this->auxSpline) MySpline(knots, ctrlPts);

			break;
		}

		std::cout << "END OF SOLVE CALL" << std::endl;

		delete[] optParam;
		delete[] tolEq;
		delete[] tolIneq;
	}

	/*

	Inequations should be in the form:
											myconstraint(x) <= 0

	*/

	double PathPlannerRecedingHorizIpopt::objectFunc(unsigned n, const double *x, double *grad, void *my_func_data)
	{

		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(my_func_data);

		RecHorNLP * myNLP = static_cast<RecHorNLP*>(thisPP->myNLP);

		double fx;
		myNLP->eval_f(n, x, true, fx);

		std::ofstream arquivo;
		arquivo.open("optlog/xiter.csv", std::fstream::app);
		for (int i = 0; i < int(n); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << x[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();
		arquivo.open("optlog/citer.csv", std::fstream::app);
		arquivo << fx << std::endl;
		arquivo.close();

		if (grad)
		{
			//myNLP->eval_grad_f ( n, x, true, grad );

			for (unsigned i = n - 1, j = 0; i > n - (thisPP->splDim - 1) - 1; --i, ++j)
			{
				grad[i] = 2 * (x[i] -
					(thisPP->targetedPose(i % (thisPP->splDim - 1) + aiv::FlatoutputMonocycle::posIdx, 0) -
						thisPP->latestPose(i % (thisPP->splDim - 1) + aiv::FlatoutputMonocycle::posIdx, 0)));
			}
			for (unsigned i = 0; i < n - (thisPP->splDim - 1); ++i)
			{
				grad[i] = 0.0;
			}
		}
		return fx;
	}

	void PathPlannerRecedingHorizIpopt::eqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
	{
		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(data);

		std::ofstream arquivo;
		arquivo.open("optlog/geqiter.csv", std::fstream::app);

		std::ofstream arquivo2;
		arquivo2.open("optlog/giter.csv", std::fstream::app);

		RecHorNLP * myNLP = static_cast<RecHorNLP*>(thisPP->myNLP);

		int compM = m + myNLP->get_nIneq();

		double *allConstr = new double[compM];
		myNLP->eval_g(n, x, true, compM, allConstr);

		for (int i = 0; i < compM; ++i)
		{
			arquivo2 << allConstr[i] << ", ";
		}

		for (int i = 0; i < int(m); ++i)
		{
			result[i] = allConstr[i];
		}


		for (int i = 0; i < int(m); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << result[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();

		arquivo2 << std::endl;
		arquivo2.close();

		if (grad)
		{

			double *x1 = new double[n];

			for (int i = 0; i < int(n); ++i)
			{
				x1[i] = x[i];
			}

			for (int i = 0; i < int(n); ++i)
			{
				x1[i] += thisPP->h;
				myNLP->eval_g(n, x1, true, compM, allConstr);
				x1[i] -= thisPP->h;
				for (int j = 0; j < m; ++j)
				{
					grad[j*n + i] = (allConstr[j] - result[j]) / thisPP->h;
					std::cout << grad[j*n + i] << std::endl;
				}
			}
			/*
			double *compJac = new double[compM*n];

			myNLP->eval_jac_g(n, x, true, compM, 0, NULL, NULL, compJac);

			for (int i = 0; i< int(n*m); ++i)
			{
				grad[i] = compJac[i];
			}

			delete[] compJac;
			*/
		}

		delete[] allConstr;

	}

	void PathPlannerRecedingHorizIpopt::ineqFunc(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
	{
		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(data);

		RecHorNLP * myNLP = static_cast<RecHorNLP*>(thisPP->myNLP);

		int compM = myNLP->get_nEq() + m;

		double *allConstr = new double[compM];
		myNLP->eval_g(n, x, true, compM, allConstr);

		for (int i = 0; i < int(m); ++i)
		{
			result[i] = allConstr[i + myNLP->get_nEq()];
		}

		std::ofstream arquivo;
		arquivo.open("optlog/gieqiter.csv", std::fstream::app);
		for (int i = 0; i < int(m); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << result[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();

		if (grad)
		{

			double *x1 = new double[n];

			for (int i = 0; i < int(n); ++i)
			{
				x1[i] = x[i];
			}

			for (int i = 0; i < int(n); ++i)
			{
				x1[i] += thisPP->h;
				myNLP->eval_g(n, x1, true, compM, allConstr);
				x1[i] -= thisPP->h;
				for (int j = 0; j < m; ++j)
				{
					grad[j*n+i] = (allConstr[j + myNLP->get_nEq()] - result[j]) / thisPP->h;
				}
			}

			/*double *compJac = new double[compM*n];

			myNLP->eval_jac_g(n, x, true, compM, 0, NULL, NULL, compJac);

			for (int i = 0; i< int(n*m); ++i)
			{
				grad[i] = compJac[i + myNLP->get_nEq()*n];
			}
			delete[] compJac;*/
		}

		delete[] allConstr;
	}


	double PathPlannerRecedingHorizIpopt::objectFuncLS(unsigned n, const double *x, double *grad, void *my_func_data)
	{

		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(my_func_data);

		TermNLP * myNLP = static_cast<TermNLP*>(thisPP->myNLP);

		double fx;
		myNLP->eval_f(n, x, true, fx);

		std::ofstream arquivo;
		arquivo.open("optlog/xiter.csv", std::fstream::app);
		for (int i = 0; i < int(n); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << x[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();
		arquivo.open("optlog/citer.csv", std::fstream::app);
		arquivo << fx << std::endl;
		arquivo.close();

		if (grad)
		{
			//myNLP->eval_grad_f ( n, x, true, grad );
			grad[0] = 2 * x[0];
			for (unsigned i = 1; i < n; ++i)
			{
				grad[i] = 0.0;
			}
		}

		return fx;
	}

	void PathPlannerRecedingHorizIpopt::eqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
	{
		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(data);

		std::ofstream arquivo;
		arquivo.open("optlog/geqiter.csv", std::fstream::app);

		std::ofstream arquivo2;
		arquivo2.open("optlog/giter.csv", std::fstream::app);

		TermNLP * myNLP = static_cast<TermNLP*>(thisPP->myNLP);

		int compM = m + myNLP->get_nIneq();

		double *allConstr = new double[compM];
		myNLP->eval_g(n, x, true, compM, allConstr);

		for (int i = 0; i < compM; ++i)
		{
			arquivo2 << allConstr[i] << ", ";
		}

		for (int i = 0; i < int(m); ++i)
		{
			result[i] = allConstr[i];
		}


		for (int i = 0; i < int(m); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << result[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();

		arquivo2 << std::endl;
		arquivo2.close();

		if (grad)
		{
			double *compJac = new double[compM*n];

			myNLP->eval_jac_g(n, x, true, compM, 0, NULL, NULL, compJac);

			for (int i = 0; i< int(n*m); ++i)
			{
				grad[i] = compJac[i];
			}

			delete[] compJac;
		}

		delete[] allConstr;

	}

	void PathPlannerRecedingHorizIpopt::ineqFuncLS(unsigned m, double *result, unsigned n, const double* x, double* grad, void* data)
	{
		// get this path planner pointer
		PathPlannerRecedingHorizIpopt *thisPP = static_cast<PathPlannerRecedingHorizIpopt *>(data);

		TermNLP * myNLP = static_cast<TermNLP*>(thisPP->myNLP);

		int compM = myNLP->get_nEq() + m;

		double *allConstr = new double[compM];
		myNLP->eval_g(n, x, true, compM, allConstr);

		for (int i = 0; i < int(m); ++i)
		{
			result[i] = allConstr[i + myNLP->get_nEq()];
		}

		std::ofstream arquivo;
		arquivo.open("optlog/gieqiter.csv", std::fstream::app);
		for (int i = 0; i < int(m); ++i)
		{
			//x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
			arquivo << result[i] << ", ";

		}
		arquivo << std::endl;
		arquivo.close();

		if (grad)
		{
			double *compJac = new double[compM*n];

			myNLP->eval_jac_g(n, x, true, compM, 0, NULL, NULL, compJac);

			for (int i = 0; i< int(n*m); ++i)
			{
				grad[i] = compJac[i + myNLP->get_nEq()*n];
			}
			delete[] compJac;
		}

		delete[] allConstr;

	}

	Eigen::Array< double, 1, Eigen::Dynamic > PathPlannerRecedingHorizIpopt::genKnots(const double initT, const double finalT, bool nonUniform)
	{
		// TODO noIntervNonNull < 2 => error

		double d = (finalT - initT) / (4 + (this->noIntervNonNull - 2));
		// d is the nonuniform interval base value (spacing produce intervals like this: 2*d, d,... , d, 2*d)

		Eigen::Array< double, 1, Eigen::Dynamic > knots(this->splDegree * 2 + this->noIntervNonNull + 1);

		// first and last knots
		knots.head(this->splDegree) = Eigen::Array< double, 1, Eigen::Dynamic >::Constant(this->splDegree, initT);
		knots.tail(this->splDegree) = Eigen::Array< double, 1, Eigen::Dynamic >::Constant(this->splDegree, finalT);

		// intermediaries knots
		if (nonUniform)
		{
			knots(this->splDegree) = initT;
			knots(this->splDegree + 1) = initT + 2 * d;

			unsigned i = 0;
			for (i = 0; i < this->noIntervNonNull - 2; ++i)
			{
				knots(this->splDegree + i + 2) = knots(this->splDegree + i + 1) + d;
			}

			knots(this->splDegree + 2 + i) = finalT; // = knots(this->splDegree+2+i-1) + 2*d
		}
		else // uniform
		{
			knots.segment(this->splDegree, this->noIntervNonNull + 1) = Eigen::Array< double, 1, Eigen::Dynamic >::LinSpaced(this->noIntervNonNull + 1, initT, finalT);
		}
		return knots;
	}

}
