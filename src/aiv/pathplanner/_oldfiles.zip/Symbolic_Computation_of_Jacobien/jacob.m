clear all;

pkg load symbolic;
pkg load nurbs;

nk = 4; % number internal knots
l = 2; % derivative order needed

% MAXIMA another symbolic computation system

spld = l + 2; % spline order
d = spld - 1; % here spline order is one less the value used in C++ code (eigen spline)
ncp = nk + spld - 1; % number of control points

X = sym('X', [1 ncp*2]);
for i = ncp*2
  assume(X(i), 'real');
end

Tp = sym('Tp', 'real', 'positive');
knots = [0 0 0 0 .25*Tp .5*Tp .75*Tp Tp Tp Tp Tp];

%t = Tp/3;
t = sym('t', 'real', 'positive');

C = reshape(X, [2 ncp]);

% create b-spline from knots and C

[dC,dknots] = bspderivative(d, C, knots);
dC = simplify(dC);
dknots = simplify(dknots);
[ddC,ddknots] = bspderivative(d-1, dC, dknots);
ddC = simplify(ddC);
ddknots = simplify(ddknots);
[dddC,dddknots] = bspderivative(d-2, ddC, ddknots);
dddC = simplify(dddC);
dddknots = simplify(dddknots);

z = bspevaluation(d, C, knots, t);
dz = bspevaluation(d-1, dC, dknots, t);
ddz = bspevaluation(d-2, ddC, ddknots, t);
dddz = bspevaluation(d-3, dddC, dddknots, t);

g_pos = [z(1) z(2) atan2(dz(2), dz(1))];

g_vel = [norm(dz) (dz(1)*ddz(2) - dz(2)*ddz(1))/(dz(1)^2 + dz(2)^2)];

% g_acc = []

J = jacobian([g_pos g_vel], X);
% J = simplify(J);

ccodeJ = ccode(J);

filename = "eq_cons_jac.txt";
fid = fopen (filename, "w");
fputs (fid, ccodeJ);
fclose (fid);