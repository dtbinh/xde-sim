import re

def derivrplEq(mo):
	if mo.group(1) == mo.group(2):
		return '1.0'
	else:
		return '0.0'

def derivrplmEq(mo):
	if mo.group(1) == mo.group(2):
		return '-1.0'
	else:
		return '0.0'

def rplComplicPow(m, eqCons, offset):
	nclosedp = 1
	idx = m.start()-1 + offset
	while nclosedp > 0:
		if eqCons[idx] == '(':
			nclosedp -= 1
		elif eqCons[idx] == ')':
			nclosedp += 1
		idx -= 1

	nEqCons = eqCons[0:idx+1] +\
		'(pow(' + eqCons[idx+1:m.start()+1+offset] + ', ' + eqCons[m.end()-1+offset:m.end()+offset] + '))' +\
		eqCons[m.end()+offset:]

	return nEqCons

def addParenthesis(m, eqCons, offset):
	nopenedp = 1
	idx = m.end() + 1 + offset
	while nopenedp > 0:
		if eqCons[idx] == ')':
			nopenedp -= 1
		elif eqCons[idx] == '(':
			nopenedp += 1
		idx += 1

	nEqCons = eqCons[0:m.start()+offset] +\
		'(' +\
		eqCons[m.start()+offset:idx] +\
		')' +\
		eqCons[idx:]
		
	return nEqCons


f = open('eq_cons_jac.txt', 'r')
eqCons = f.read()

eqCons = re.sub(r'Abs', r'abs', eqCons)

eqCons = re.sub(r're\((X...)\)', r'\1', eqCons)
eqCons = re.sub(r'im\((X...)\)', r'0.0', eqCons)

eqCons = re.sub(r'Derivative\(([^)-]*),\s([^)-]*)\)', derivrplEq, eqCons)
eqCons = re.sub(r'Derivative\(-([^)-]*),\s([^)-]*)\)', derivrplmEq, eqCons)
eqCons = re.sub(r'Derivative\(([^)-]*),\s-([^)-]*)\)', derivrplmEq, eqCons)
eqCons = re.sub(r'Derivative\(-([^)-]*),\s-([^)-]*)\)', derivrplEq, eqCons)

eqCons = re.sub(r't\*\*(.)', r'(pow(t, \1))', eqCons)
eqCons = re.sub(r'Tp\*\*(.)', r'(pow(Tp, \1))', eqCons)
eqCons = re.sub(r'\(([^()]*)\)\*\*(.)', r'(pow(\1, \2))', eqCons)
eqCons = re.sub(r'([^()])\*\*(.)', r'(pow(\1, \2))', eqCons)

offset = 0
m = re.search(r'abs|sqrt', eqCons)
while m != None:
	eqCons = addParenthesis(m, eqCons, offset)
	offset += m.end()+1 # +1 for parenthesis
	m = re.search(r'abs|sqrt', eqCons[offset:])

offset = 0
m = re.search(r'\)\*\*.', eqCons)
while m != None:
	eqCons = rplComplicPow(m, eqCons, offset)
	offset += m.end()+7 # +1 for parenthesis
 	m = re.search(r'\)\*\*.', eqCons[offset:])

eqCons = re.sub(r'Matrix\(\[', r'Matrix <<', eqCons)
eqCons = re.sub(r'\]\]\)', r';', eqCons)
eqCons = re.sub(r'\[', r'', eqCons)
eqCons = re.sub(r'\]', r'', eqCons)

f.close()
f = open('eq_cons_jac.cpp', 'w')
f.write(eqCons)