/*----------------------------------------------------------------------------
 File:     TER_NLP.cpp
 Revision: $$
 Contents: class TermNLP for interfacing with Ipopt
 
 Copyright (c) Jose Magno MENDES
   
 This file is part of . This software is provided as open source.
 Any use, reproduction, or distribution of the software constitutes 
 recipient's acceptance of the terms of the accompanying license file.
 
 This code is based on the file  MyADOLC_NLP.cpp contained in the Ipopt package
 with the authors:  Carl Laird, Andreas Waechter   
----------------------------------------------------------------------------*/

/** C++ Example NLP for interfacing a problem with IPOPT and ADOL-C.
 *  RH_NLP implements a C++ example showing how to interface 
 *  with IPOPT and ADOL-C through the TNLP interface. This class 
 *  implements a distributed control problem with nonholomic, geometric
 *  and kinematic constraints.
 *
 *  no exploitation of sparsity !!
 *
 */

#include <cassert>
#include <iostream>
#include <fstream>

#include "TER_NLP.hpp"

using namespace Ipopt;

/* Constructor. */
TermNLP::TermNLP ( const unsigned nParam_, const unsigned nEq_, const unsigned nIeq_ ,
    const unsigned nbCtrlPts_, const unsigned nbTimeSamples_, const MySpline & startSpline_, 
    const PoseVector & goalPose_, const PoseVector & latestPose_, const VelVector & goalVelocity_,
    const VelVector & latestVelocity_, const VelVector & maxVelocity_,
    const AccVector & maxAcceleration_, double * optParam_ )
	: nParam(nParam_)
	, nEq(nEq_)
	, nIeq(nIeq_)
  , nbCtrlPts(nbCtrlPts_)
  , nbTimeSamples(nbTimeSamples_)
  , startSpline(startSpline_)
  , goalPose(goalPose_)
  , latestPose(latestPose_)
  , goalVelocity(goalVelocity_)
  , latestVelocity(latestVelocity_)
  , maxVelocity(maxVelocity_)
  , maxAcceleration(maxAcceleration_)
  , optParam(optParam_)
  , planHorizon(startSpline_.ctrls().row(0).tail<1>()(0))
{
	std::cout << "\n\n ------------- \n\n" << planHorizon << "\n\n ------------- \n\n";
}

/* Desconstructor */
TermNLP::~TermNLP()
{}

/*
virtual bool get_nlp_info(Index& n, Index& m, Index& nnz_jac_g,
                          Index& nnz_h_lag, IndexStyleEnum& index_style)
Give IPOPT the information about the size of the problem (and hence, the size of the arrays that it needs to allocate).
n: (out), the number of variables in the problem (dimension of $ x$ ).
m: (out), the number of constraints in the problem (dimension of $ g(x)$ ).
nnz_jac_g: (out), the number of nonzero entries in the Jacobian.
nnz_h_lag: (out), the number of nonzero entries in the Hessian.
index_style: (out), the numbering style used for row/col entries in the sparse matrix format (C_STYLE: 0-based, FORTRAN_STYLE: 1-based; see also Appendix A).
*/

bool TermNLP::get_nlp_info(Index& n, Index& m, Index& nnz_jac_g,
                         Index& nnz_h_lag, IndexStyleEnum& index_style)
{
  n = nParam;
  std::cout << "N: " << n << std::endl;
  m = nEq+nIeq;
  std::cout << "M: " << m << std::endl;
  //m = nEq + nIeq - (nbTimeSamples-1)*aiv::FlatoutputMonocycle::accelerationDim;
  //m= nEq;
  //std::cout << "---------- DIMS " << n << std::endl << m << std::endl;

  // in this example the jacobian is dense. Hence, it contains n*m nonzeros
  nnz_jac_g = n*m;

  // the hessian is also dense and has n*n total nonzeros, but we
  // only need the lower left corner (since it is symmetric)
  nnz_h_lag = n*(n-1)/2+n;
  
  std::cout << "call generate tapes" << std::endl;
  generate_tapes(n, m);
  std::cout << "done generating tapes" << std::endl;

  // use the C style indexing (0-based)
  index_style = C_STYLE;

  return true;
}

/*
virtual bool get_bounds_info(Index n, Number* x_l, Number* x_u,
                             Index m, Number* g_l, Number* g_u)
Give IPOPT the value of the bounds on the variables and constraints.
n: (in), the number of variables in the problem (dimension of $ x$ ).
x_l: (out) the lower bounds $ x^L$ for $ x$ .
x_u: (out) the upper bounds $ x^U$ for $ x$ .
m: (in), the number of constraints in the problem (dimension of $ g(x)$ ).
g_l: (out) the lower bounds $ g^L$ for $ g(x)$ .
g_u: (out) the upper bounds $ g^U$ for $ g(x)$ .
*/
bool TermNLP::get_bounds_info(Index n, Number* x_l, Number* x_u,
                            Index m, Number* g_l, Number* g_u)
{
  // none of the variables have bounds
  for (Index i=0; i<n; i++) {
    x_l[i] = -2e19; // < nlp_lower_bound_inf therefore no lower bound
    x_u[i] =  2e19; // > nlp_upper_bound_inf therefore no upper bound
  }

  // Set the bounds for the constraints
  //	equations
  for (Index i=0; i<int(nEq); i++)
  {
    g_l[i] = 0.0;
    g_u[i] = 0.0;
  }
  //	inequations
  for (Index i=nEq; i < m; i++) 
  {
    g_l[i] = -2e19;
    g_u[i] = 0.0; // > nlp_upper_bound_inf therefore no upper bound
  }

  return true;
}

/*
virtual bool get_starting_point(Index n, bool init_x, Number* x,
                                bool init_z, Number* z_L, Number* z_U,
                                Index m, bool init_lambda, Number* lambda)
Give IPOPT the starting point before it begins iterating.
n: (in), the number of variables in the problem (dimension of $ x$ ).
init_x: (in), if true, this method must provide an initial value for $ x$ .
x: (out), the initial values for the primal variables, $ x$ .
init_z: (in), if true, this method must provide an initial value for the bound multipliers $ z^L$ and $ z^U$ .
z_L: (out), the initial values for the bound multipliers, $ z^L$ .
z_U: (out), the initial values for the bound multipliers, $ z^U$ .
m: (in), the number of constraints in the problem (dimension of $ g(x)$ ).
init_lambda: (in), if true, this method must provide an initial value for the constraint multipliers, $ \lambda$ .
lambda: (out), the initial values for the constraint multipliers, $ \lambda$ .
*/
bool TermNLP::get_starting_point(Index n, bool init_x, Number* x,
                               bool init_z, Number* z_L, Number* z_U,
                               Index m, bool init_lambda,
                               Number* lambda)
{
  // Here, we assume we only have starting values for x, if you code
  // your own NLP, you can provide starting values for the others if
  // you wish.
  assert(init_x == true);
  assert(init_z == false);
  assert(init_lambda == false);

  x[0] = 1.0; // TODO

  for ( int i = 1; i < n; ++i )
	{
    x[i] = startSpline.ctrls()(i%(splDim-1)+1, i/(splDim-1));
    //std::cout << "X[" << i << "]  " << x[i] << std::endl;
	}

  return true;
}

template<class T> bool  TermNLP::eval_obj(Index n, const T *x, T& obj_value)
{
  obj_value = x[0]*x[0];
  return true;
}

template<class T> bool  TermNLP::eval_constraints(Index n, const T *x, Index m, T* g)
{
  //std::cout << "eval_constraints" << std::endl;
  typedef Eigen::Spline< T, aiv::FlatoutputMonocycle::flatDim + 1, aiv::FlatoutputMonocycle::flatDerivDeg + 1 > Spline_T;
  typedef Eigen::Matrix< T, aiv::FlatoutputMonocycle::poseDim, 1 > PoseVector_T;
  typedef Eigen::Matrix< T, aiv::FlatoutputMonocycle::velocityDim, 1 > VelVector_T;
  typedef Eigen::Matrix< T, aiv::FlatoutputMonocycle::accelerationDim, 1 > AccVector_T;

  // Create a CtrlPoints vector
  Spline_T::ControlPointVectorType ctrlPts(splDim, nbCtrlPts);

  //std::cout << "-------------- latestPose\n" << latestPose << "--------------" << std::endl;
  //std::cout << "-------------- goalPose\n" << goalPose << "--------------" << std::endl;
  //std::cout << "-------------- maxVelocity\n" << maxVelocity << "--------------" << std::endl;
  //std::cout << "-------------- x[0]\n" << x[0] << "--------------" << std::endl;
  //std::cout << "-------------- x[1]\n" << x[1] << "--------------" << std::endl;

  // Feed first row with the time row
  ctrlPts.row(0) = startSpline.ctrls().row(0).cast<T>();

  // Feed remaining rows with values from the primal variables x
  for ( int i = 0; i < n-1; ++i )
  {
    ctrlPts(i%(splDim-1)+1, i/(splDim-1)) = x[i+1];
  }

  // Create a spline based on the new ctrlpts (using the same knots as before)
  Spline_T optSpline((startSpline.knots()).cast<T>(), ctrlPts);


  // EQUATIONS


  Eigen::Matrix< T, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlatT0;
  Eigen::Matrix< T, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlatTf;

  derivFlatT0 =
        optSpline.derivatives(
        0.0, aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  derivFlatTf =
        optSpline.derivatives(
        planHorizon, aiv::FlatoutputMonocycle::flatDerivDeg
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);


  PoseVector_T pose = aiv::FlatoutputMonocycle::flatToPose ( derivFlatT0 );
  PoseVector_T diffPoseAtT0 = pose - latestPose.cast<T>();
  diffPoseAtT0.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) =
      pose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0);

  VelVector_T diffVelocityAtT0 = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlatT0 ) - latestVelocity.cast<T>();

  pose = aiv::FlatoutputMonocycle::flatToPose ( derivFlatTf );
  PoseVector_T diffPoseAtTf = pose - goalPose.cast<T>();
  diffPoseAtTf.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0) +=
      latestPose.block<aiv::FlatoutputMonocycle::posDim, 1>(aiv::FlatoutputMonocycle::posIdx, 0).cast<T>();

  VelVector_T diffVelocityAtTf = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlatTf ) - goalVelocity.cast<T>();

  int i = 0;
  //std::cout << "POS ERROR\n";
  for (; i < aiv::FlatoutputMonocycle::poseDim; ++i )
  {
    g[i] = diffPoseAtT0[i];
    //std::cout << ' ' << result[i];
  }
  //std::cout << "\nVEL ERROR\n";
  int j;
  for ( j = i; j-i < aiv::FlatoutputMonocycle::velocityDim; ++j )
  {
    g[j] = diffVelocityAtT0[j-i];
    //std::cout << ' ' << result[j];
  }
  for (i = j; i-j < aiv::FlatoutputMonocycle::poseDim; ++i )
  {
    g[i] = diffPoseAtTf[i-j];
    //std::cout << ' ' << result[i];
  }
  //std::cout << "\nVEL ERROR\n";
  for ( j = i; j-i < aiv::FlatoutputMonocycle::velocityDim; ++j )
  {
    g[j] = diffVelocityAtTf[j-i];
    //std::cout << ' ' << result[j];
  }


  // INEQUATIONS


  // Create a Matrix for storing the flat output and its needed derivatives for all tk in ]0.0, 1]
  Eigen::Matrix< T, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1 > derivFlatEq;
  Eigen::Matrix< T, aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1+1 > derivFlat;

  // Create Matrices for storing velocity and acceleration for all tk in ]0.0, 1]
  VelVector_T velocity;
  AccVector_T acceleration;

  derivFlat =
      optSpline.derivatives(
      0.0, aiv::FlatoutputMonocycle::flatDerivDeg+1
      ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  //std::cout << "got acc" << std::endl;
  acceleration = aiv::FlatoutputMonocycle::flatToAcceleration ( derivFlat );
  j=0;
  for (; j < aiv::FlatoutputMonocycle::accelerationDim; ++j )
  {
    const T absAcc = (acceleration(j, 0) > -acceleration(j, 0)) ? acceleration(j, 0) : -acceleration(j, 0);
    g[nEq+j] =  absAcc - maxAcceleration(j,0);
    //std::cout << "G[" << nEq+j+(i-1)*ieqPerSample << "] " << g[nEq+j+(i-1)*ieqPerSample] << std::endl;
  }

  int nEqAcc = nEq+j;

  derivFlat =
      optSpline.derivatives(
      planHorizon, aiv::FlatoutputMonocycle::flatDerivDeg+1
      ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

  //std::cout << "got acc" << std::endl;
  acceleration = aiv::FlatoutputMonocycle::flatToAcceleration ( derivFlat );

  for ( j = 0; j < aiv::FlatoutputMonocycle::accelerationDim; ++j )
  {
    const T absAcc = (acceleration(j, 0) > -acceleration(j, 0)) ? acceleration(j, 0) : -acceleration(j, 0);
    g[nEqAcc+j] =  absAcc - maxAcceleration(j,0);
    //std::cout << "G[" << nEq+j+(i-1)*ieqPerSample << "] " << g[nEq+j+(i-1)*ieqPerSample] << std::endl;
  }

  nEqAcc += j;

  //#pragma omp parallel for
  for ( int i = 1; i < int(nbTimeSamples)-1; ++i )
  {

    derivFlat =
        optSpline.derivatives(
        double(i)/(nbTimeSamples-1)*planHorizon, aiv::FlatoutputMonocycle::flatDerivDeg+1
        ).bottomRows(aiv::FlatoutputMonocycle::flatDim);

    derivFlatEq = derivFlat.block<aiv::FlatoutputMonocycle::flatDim, aiv::FlatoutputMonocycle::flatDerivDeg+1>(0, 0);

    velocity = aiv::FlatoutputMonocycle::flatToVelocity ( derivFlatEq );

    acceleration = aiv::FlatoutputMonocycle::flatToAcceleration ( derivFlat );

    int ieqPerSample = (aiv::FlatoutputMonocycle::velocityDim+aiv::FlatoutputMonocycle::accelerationDim);
    //int ieqPerSample = (aiv::FlatoutputMonocycle::velocityDim);

    int j;
    for ( j = 0; j < aiv::FlatoutputMonocycle::velocityDim; ++j )
    {
      const T absVel = (velocity(j, 0) > -velocity(j, 0)) ? velocity(j, 0) : -velocity(j, 0);
      g[nEqAcc+j+(i-1)*ieqPerSample] =  absVel - maxVelocity(j,0);
      //std::cout << "G[" << nEq+j+(i-1)*ieqPerSample << "] " << g[nEq+j+(i-1)*ieqPerSample] << std::endl;
    }

    for ( int k = j; k-j < aiv::FlatoutputMonocycle::accelerationDim; ++k )
    {
      const T absAcc = (acceleration(k-j, 0) > -acceleration(k-j, 0)) ? acceleration(k-j, 0) : -acceleration(k-j, 0);
      g[nEqAcc+k+(i-1)*ieqPerSample] = absAcc - maxAcceleration(k-j,0) ;
      //std::cout << "G[" << nEq+k+(i-1)*ieqPerSample << "] " << g[nEq+k+(i-1)*ieqPerSample] << std::endl;
    }

  }

  return true;
}

//void TermNLP::get_x ( double* x_out )
//{
//  for (Index i=0; i<nParam; i++)
//  {
//    x_out[i] = xSolution[i];
//  }
//  
//  delete[] xSolution;
//}

//*************************************************************************
//
//
//         Nothing has to be changed below this point !!
//
//
//*************************************************************************


bool TermNLP::eval_f(Index n, const Number* x, bool new_x, Number& obj_value)
{
  eval_obj(n,x,obj_value);

  return true;
}

bool TermNLP::eval_grad_f(Index n, const Number* x, bool new_x, Number* grad_f)
{

  gradient(tag_f,n,x,grad_f);

  return true;
}

bool TermNLP::eval_g(Index n, const Number* x, bool new_x, Index m, Number* g)
{

  eval_constraints(n,x,m,g);

  return true;
}

bool TermNLP::eval_jac_g(Index n, const Number* x, bool new_x,
                       Index m, Index nele_jac, Index* iRow, Index *jCol,
                       Number* values)
{

  if (values == NULL) {
    // return the structure of the jacobian, 
    // assuming that the Jacobian is dense

    Index idx = 0;
    for(Index i=0; i<m; i++)
      for(Index j=0; j<n; j++)
	{
	  iRow[idx] = i;
	  jCol[idx++] = j;
	}
 }
  else {
    // return the values of the jacobian of the constraints

    jacobian(tag_g,m,n,x,Jac);

    Index idx = 0;
    for(Index i=0; i<m; i++)
      for(Index j=0; j<n; j++)
	  values[idx++] = Jac[i][j];

  }

  return true;
}

bool TermNLP::eval_h(Index n, const Number* x, bool new_x,
                   Number obj_factor, Index m, const Number* lambda,
                   bool new_lambda, Index nele_hess, Index* iRow,
                   Index* jCol, Number* values)
{
  if (values == NULL) {
    // return the structure. This is a symmetric matrix, fill the lower left
    // triangle only.

    // the hessian for this problem is actually dense
    Index idx=0;
    for (Index row = 0; row < n; row++) {
      for (Index col = 0; col <= row; col++) {
        iRow[idx] = row;
        jCol[idx] = col;
        idx++;
      }
    }

    assert(idx == nele_hess);
  }
  else {
    // return the values. This is a symmetric matrix, fill the lower left
    // triangle only

    for(Index i = 0; i<n ; i++)
      x_lam[i] = x[i];
    for(Index i = 0; i<m ; i++)
      x_lam[n+i] = lambda[i];
    x_lam[n+m] = obj_factor;

    hessian(tag_L,n+m+1,x_lam,Hess);

    Index idx = 0;

    for(Index i = 0; i<n ; i++)
      {
	for(Index j = 0; j<=i ; j++)
	  {
	    values[idx++] = Hess[i][j];
	  }
      }
  }

  return true;
}

void TermNLP::finalize_solution(SolverReturn status,
                              Index n, const Number* x, const Number* z_L, const Number* z_U,
                              Index m, const Number* g, const Number* lambda,
                              Number obj_value,
			                        const IpoptData* ip_data,
			                        IpoptCalculatedQuantities* ip_cq)
{
 
  std::ofstream writer;
  writer.open("optlog/xSolutions.csv", std::fstream::app);
  std::cout << "\n\nObjective value" << std::endl;
  std::cout << "f(x*) = " << obj_value << std::endl;

  //xSolution = new double[n];

  // we write the solution to the console
  std::cout << "\n\nSolution of the primal variables, x" << std::endl;
  for (Index i=0; i<n; i++)
  {
    //xSolution[i] = x[i];
    std::cout << "x[" << i << "] = " << x[i] << std::endl;
    writer << x[i] << ",";
    if ( optParam != NULL )
    {
      optParam[i] = x[i];
    }
  }
  writer << std::endl;
  writer.close();

  // we write the solution to the console
  if ( g != NULL )
  {
    std::cout << "\n\nSolution of the constraints, g" << std::endl;
    for (Index i=0; i<m; i++)
    {
      std::cout << "g[" << i << "] = " << g[i] << std::endl; 
    }
  }

// Memory deallocation for ADOL-C variables

  delete[] x_lam;

  for(Index i=0;i<m;i++)
    delete[] Jac[i];
  delete[] Jac;

  for(Index i=0;i<n+m+1;i++)
    delete[] Hess[i];
  delete[] Hess;

}


//***************    ADOL-C part ***********************************

void TermNLP::generate_tapes(Index n, Index m)
{
  Number *xp    = new double[n];
  Number *lamp  = new double[m];
  Number *zl    = new double[m];
  Number *zu    = new double[m];

  adouble *xa   = new adouble[n];
  adouble *g    = new adouble[m];
  adouble *lam  = new adouble[m];
  adouble sig;
  adouble obj_value;
  
  double dummy;

  Jac = new double*[m];
  for(Index i=0;i<m;i++)
    Jac[i] = new double[n];

  x_lam   = new double[n+m+1];

  Hess = new double*[n+m+1];
  for(Index i=0;i<n+m+1;i++)
    Hess[i] = new double[i+1];

  get_starting_point(n, 1, xp, 0, zl, zu, m, 0, lamp);

  trace_on(tag_f);
    
    for(Index i=0;i<n;i++)
      xa[i] <<= xp[i];

    eval_obj(n,xa,obj_value);

    obj_value >>= dummy;

  trace_off();
  
  trace_on(tag_g);
    
    for(Index i=0;i<n;i++)
      xa[i] <<= xp[i];

    eval_constraints(n,xa,m,g);


    for(Index i=0;i<m;i++)
      g[i] >>= dummy;

  trace_off();

   trace_on(tag_L);
    
    for(Index i=0;i<n;i++)
      xa[i] <<= xp[i];
    for(Index i=0;i<m;i++)
      lam[i] <<= 1.0;
    sig <<= 1.0;

    eval_obj(n,xa,obj_value);

    obj_value *= sig;
    eval_constraints(n,xa,m,g);
 
    for(Index i=0;i<m;i++)
      obj_value += g[i]*lam[i];

    obj_value >>= dummy;

  trace_off();

  delete[] xa;
  delete[] xp;
  delete[] g;
  delete[] lam;
  delete[] lamp;
  delete[] zu;
  delete[] zl;
}
